﻿using HealthBroBackend.DTOs;
using HealthBroBackend.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HealthBroBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        [HttpPost("SaltRequest/{loginName}")]
        public async Task<IActionResult> SaltRequest(string loginName)
        {
            using (var cx = new HealthbroContext())
            {
                try
                {
                    User response = await cx.Users.FirstOrDefaultAsync(f => f.LoginNev == loginName);
                    if (response == null)
                    {
                        return BadRequest("Hiba");
                    }
                    return Ok(response.Salt);
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginDTO loginDTO)
        {
            using (var cx = new HealthbroContext())
            {
                try
                {
                    // Ellenőrizd, hogy a loginDTO nem null és mindkét mező kitöltött
                    if (string.IsNullOrEmpty(loginDTO.Email) || string.IsNullOrEmpty(loginDTO.Password))
                    {
                        return BadRequest("Email és jelszó megadása kötelező!");
                    }

                    // Keresd meg a felhasználót az email alapján
                    User loggedUser = await cx.Users.FirstOrDefaultAsync(f => f.Email == loginDTO.Email);

                    if (loggedUser == null)
                    {
                        return BadRequest("Helytelen email vagy jelszó!");
                    }

                    // A jelszó hash-olása és ellenőrzése
                    string hash = HealthBroBackend.Program.CreateSHA256(loginDTO.Password + loggedUser.Salt);
                    if (loggedUser.Hash != hash)
                    {
                        return BadRequest("Helytelen email vagy jelszó!");
                    }

                    // Ellenőrizd, hogy a felhasználó aktív
                    if (!loggedUser.Active)
                    {
                        return BadRequest("A felhasználó inaktív. Kérjük, lépj kapcsolatba az ügyfélszolgálattal!");
                    }

                    // Token generálása
                    string token = Guid.NewGuid().ToString();
                    lock (Program.LoggedInUsers)
                    {
                        Program.LoggedInUsers.Add(token, loggedUser);
                    }

                    // Válasz visszaadása
                    return Ok(new LoggedUser
                    {
                        Name = loggedUser.Name,
                        Email = loggedUser.Email,
                        Permission = loggedUser.PermissionId,
                        ProfilePicturePath = loggedUser.ProfilePicturePath,
                        Token = token
                    });
                }
                catch (Exception ex)
                {
                    return BadRequest(new { Message = "Szerverhiba történt!", Details = ex.Message });
                }
            }
        }

        [HttpGet("GetLoggedInUser/{token}")]
        public IActionResult GetLoggedInUser(string token)
        {
            lock (Program.LoggedInUsers)
            {
                if (Program.LoggedInUsers.TryGetValue(token, out User? user))
                {
                    return Ok(new LoggedUser
                    {
                        Name = user.Name,
                        Email = user.Email,
                        Permission = user.PermissionId,
                        ProfilePicturePath = user.ProfilePicturePath,
                        Token = token
                    });
                }
                return BadRequest("Érvénytelen vagy lejárt token!");
            }
        }
    }
}
