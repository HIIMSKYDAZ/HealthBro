﻿namespace HealthBroBackend.DTOs
{
    public class LoginDTO
    {
        public string Email { get; set; } // Az email mező a frontendből
        public string Password { get; set; } // A jelszó mező a frontendből
    }
}
