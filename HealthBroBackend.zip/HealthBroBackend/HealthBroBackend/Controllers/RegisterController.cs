﻿using HealthBroBackend.DTOs;
using HealthBroBackend.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Route("api/[controller]")]
[ApiController]
public class RegisterController : ControllerBase
{
    // Már meglévő kód...

    [HttpPost("Register")]
    public async Task<IActionResult> Register(RegisterDTO registerDTO)
    {
        using (var cx = new HealthbroContext())
        {
            try
            {
                // Ellenőrizzük, hogy létezik-e már a felhasználónév vagy email
                bool userExists = await cx.Users.AnyAsync(u => u.LoginNev == registerDTO.LoginName || u.Email == registerDTO.Email);
                if (userExists)
                {
                    return BadRequest("A felhasználónév vagy email már használatban van!");
                }

                // Generáljuk a sót és a hash-t
                string salt = HealthBroBackend.Program.GenerateSalt();
                string hashedPassword = HealthBroBackend.Program.CreateSHA256(registerDTO.Password + salt);

                // Új felhasználó létrehozása
                var newUser = new User
                {
                    LoginNev = registerDTO.LoginName,
                    Email = registerDTO.Email,
                    Name = registerDTO.Name,
                    Salt = salt,
                    Hash = hashedPassword,
                    Active = true, // Automatikusan aktív
                    PermissionId = 1, // Alapértelmezett jogosultság, ha van
                    ProfilePicturePath = "", // Kép üresen, ha nincs
                };

                // Felhasználó hozzáadása az adatbázishoz
                cx.Users.Add(newUser);
                await cx.SaveChangesAsync();

                return Ok("Sikeres regisztráció!");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }

    // Már meglévő kód...
}
